# =号赋值的本质是引用赋值

a = 1
print('id(a)：', id(a), 'id(1)：', id(1))
b = a
print('id(b)：', id(b), 'id(1)：', id(1))
a = 2
print('id(a)：', id(a), 'id(2)：', id(2))

print('=' * 20)

laowang_li = [3000, 5000]
laojia_li = laowang_li

print(laowang_li, laojia_li)

laowang_li[1] = 3000
print(laowang_li, laojia_li)


