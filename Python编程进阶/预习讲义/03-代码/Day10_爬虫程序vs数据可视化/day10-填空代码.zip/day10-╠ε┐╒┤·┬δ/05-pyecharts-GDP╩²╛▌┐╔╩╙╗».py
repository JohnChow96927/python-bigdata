"""
pyecharts-GDP数据可视化
学习目标：能够使用 pyecharts 绘制饼图
"""

# 需求
# ① 从文件中读取 GDP 数据
# ② 使用 pyecharts 绘制饼状图显示GDP前十的国家

