"""
logging模块记录日志
学习目标：能够使用 logging 模块记录日志
"""

import logging

# 设置记录日志的等级
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',
                    filename='./log.txt',
                    filemode='a')

# 记录日志，logging模块默认记录日志的等级是WARNING等级，只有大于等级默认记录等级的日志才会被真的记录
logging.debug('这是一个Debug等级的日志')
logging.info('这是一个Info等级的日志')
logging.warning('这是一个warning级别的日志')
logging.error('这是一个error级别的日志')
logging.critical('这是一个critical级别的日志')


