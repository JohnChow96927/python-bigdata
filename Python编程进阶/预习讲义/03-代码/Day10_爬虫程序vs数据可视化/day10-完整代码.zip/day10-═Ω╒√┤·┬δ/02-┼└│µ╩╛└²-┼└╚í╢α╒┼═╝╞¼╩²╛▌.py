"""
爬虫示例-爬虫多张图片数据
学习目标：能够使用 requests 爬取多张图片数据并保存
"""

import requests
import re

# 需求：访问 http://127.0.0.1:8080/index.html 网址，获取页面上的所有图片保存到本地。

# 思路
# ① 请求 http://127.0.0.1:8080/index.html 网址，获取响应的 html 内容
# ② 使用正则从响应的 html 内容中提取出页面上图片的地址
# ③ 遍历向每个图片地址发送请求，获取响应的图片内容并保存成本地的图片文件


# ① 请求 http://127.0.0.1:8080/index.html 网址，获取响应的 html 内容
url = 'http://127.0.0.1:8080/index.html'
response = requests.get(url)
html_str = response.content.decode()
print(html_str)

# ② 使用正则从响应的 html 内容中提取出页面上图片的地址
image_list = re.findall(r'<img src="(.*?)"', html_str)
print(image_list)

# ③ 遍历向每个图片地址发送请求，获取响应的图片内容并保存成本地的图片文件
base_url = 'http://127.0.0.1:8080'

for i, image_url in enumerate(image_list):
    # 拼接完整图片地址
    image_url = base_url + image_url[1:]

    # 向每个图片地址发送请求
    image_response = requests.get(image_url)

    # 获取响应图片的内容，并保存成本地的图片文件
    with open(f'./spider/{i}.jpg', 'wb') as f:
        f.write(image_response.content)












