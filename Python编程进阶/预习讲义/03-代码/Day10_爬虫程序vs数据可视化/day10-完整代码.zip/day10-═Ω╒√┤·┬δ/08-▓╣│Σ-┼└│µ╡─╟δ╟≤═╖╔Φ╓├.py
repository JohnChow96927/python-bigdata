import requests

# url = 'https://www.baidu.com'
url = 'http://www.supei.com/www/mysupei.jsp?r=1637813427998'

header_dict = {
    # 很多网站会通过这个请求头识别是不是一个爬虫程序
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                  ' (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    # 有些时候访问的网址需要登录，Web 服务器会通过 Cookie 中的 sessionid 会判断用户是否登录
    'Cookie': 'JSESSIONID=104840480E26CB86094EC5AE6815A372; '
              'COMEFROM=www.baidu.com; HID=20211125120929_10_1536x864; MYLOGINID=itcast'
}


response = requests.get(url, headers=header_dict)

# 查看爬虫程序请求时请求头信息
print(response.request.headers)

print(response.content.decode('gbk'))
