"""
pyecharts-GDP数据可视化
学习目标：能够使用 pyecharts 绘制饼图
"""

# 需求
# ① 从文件中读取 GDP 数据
# ② 使用 pyecharts 绘制饼状图显示GDP前十的国家

# 导入模块
# 导入饼图类
from pyecharts.charts import Pie
# 导入配置选项模块
import pyecharts.options as opts


# ① 从文件中读取 GDP 数据
gdp_list = []

with open('./spider/gdp.txt', 'r', encoding='utf8') as f:
    # 读取文件的内容
    content = f.read() # str
    gdp_list = eval(content)

# ② 使用 pyecharts 绘制饼状图显示GDP前十的国家
# 获取 GDP 前 10 的国家数据
gdp_top10 = gdp_list[:10]
print(gdp_top10)

# 创建一个饼图对象
pie = Pie(init_opts=opts.InitOpts(width="1400px", height="800px"))
# 给饼图添加数据
pie.add('GDP',
        gdp_top10,
        label_opts=opts.LabelOpts(formatter='{b}:{d}%'))

# 给饼图设置标题
pie.set_global_opts(title_opts=opts.TitleOpts(title="2020年世界GDP排名", subtitle="美元"))

# 进行饼图的绘制
pie.render()
