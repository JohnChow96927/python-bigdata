"""
爬虫示例-爬取GDP数据
学习目标：能够使用 requests 爬取GDP数据并保存
"""

# 需求：访问 http://127.0.0.1:8080/gdp.html 网址，提取页面上的国家和GDP数据并保存到本地。

# 思路
# ① 先请求 http://127.0.0.1:8080/gdp.html 网址，获取响应的 html 内容
# ② 使用正则提取 html 内容中的 GDP 数据：国家、GDP
# ③ 将提取的 GDP 数据保存 gdp.txt 文件中

import requests
import re

# ① 先请求 http://127.0.0.1:8080/gdp.html 网址，获取响应的 html 内容
url = 'http://127.0.0.1:8080/gdp.html'
response = requests.get(url)
html_str = response.content.decode()
print(html_str)

# ② 使用正则提取 html 内容中的 GDP 数据：国家、GDP
gdp_list = re.findall(r'<a href=""><font>(.*?)</font></a>.*?<font>￥(.*?)亿元</font>', html_str, flags=re.S)
print(gdp_list) # list

# ③ 将提取的 GDP 数据保存 gdp.txt 文件中
with open('./spider/gdp.txt', 'w', encoding='utf8') as f:
    f.write(str(gdp_list))

