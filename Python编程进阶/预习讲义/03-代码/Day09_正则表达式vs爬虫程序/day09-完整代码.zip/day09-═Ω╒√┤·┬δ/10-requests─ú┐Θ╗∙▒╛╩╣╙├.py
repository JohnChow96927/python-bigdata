"""
requests模块基本使用
学习目标：能够使用 requests 模块请求URL地址并获取响应内容
"""

# 导入 requests 包
import requests

# 准备 url 地址
url = 'https://www.baidu.com'

# 使用 requests 发送 GET 请求
# 响应对象
response = requests.get(url)

# 获取响应的内容
# response.content：bytes，服务器返回的原始响应内容
# bytes -> str：bytes数据.decode('解码方式')
print(response.content.decode())


