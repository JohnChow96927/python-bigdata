"""
正则表达式修饰符
学习目标：知道re.I、re.M、re.S三个正则表示式修饰符的作用
"""

"""
re.I：匹配时不区分大小写
re.M：多行匹配，影响 ^ 和 $
re.S：影响 . 符号，设置之后，.符号就能匹配\n了
"""

import re

my_str = 'aB'

# re.I：匹配时不区分大小写
res = re.match(r'ab', my_str, flags=re.I)
print(bool(res)) # 非None就True，None就是False


print('=' * 20)
# 开启多行模式
# ^　可以匹配字符串开头（字符串的开始位置），也可以匹配行的开头（即换行符\n之后的位置）
# $　可以匹配字符串结尾（字符串的结束位置）, 也可以匹配行的结尾（即换行符\n之前的位置）

# 关闭多行模式
# ^　只能匹配字符串开头
# $　只能匹配字符串结尾
my_str = 'aabb\nbbcc'

res = re.findall(r'^[a-z]{4}$', my_str, flags=re.M)
print(res)
print(bool(res))
print('=' * 20)

my_str = '\nabc'
# re.S：影响 . 符号，设置之后，.符号就能匹配\n了
res = re.match(r'.', my_str, flags=re.S)
print(bool(res))