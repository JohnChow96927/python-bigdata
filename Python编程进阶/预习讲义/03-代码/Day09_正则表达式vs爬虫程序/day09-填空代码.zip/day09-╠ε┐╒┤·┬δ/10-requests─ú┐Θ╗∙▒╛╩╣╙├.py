"""
requests模块基本使用
学习目标：能够使用 requests 模块请求URL地址并获取响应内容
"""

# TODO：需求：使用 requests 请求百度，并获取响应内容


