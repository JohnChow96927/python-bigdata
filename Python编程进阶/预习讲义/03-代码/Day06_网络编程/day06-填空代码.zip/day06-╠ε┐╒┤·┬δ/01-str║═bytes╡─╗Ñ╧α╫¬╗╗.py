"""
str和bytes的互相转换
学习目标：知道str和bytes数据之间的互相转换
"""
# str -> bytes：str.encode('编码方式：默认utf8')
# bytes -> str：bytes.decode('解码方式：默认utf8')

my_str = '你好！中国！' # str


