"""
str和bytes的互相转换
学习目标：知道str和bytes数据之间的互相转换
"""
# str -> bytes：str.encode('编码方式：默认utf8')
# bytes -> str：bytes.decode('解码方式：默认utf8')

my_str = '你好！中国！' # str

print(type(my_str), my_str)

res1 = my_str.encode('utf8')
print(type(res1), res1)

res2 = my_str.encode('gbk')
print(type(res2), res2)

res3 = res1.decode('utf8')
print(type(res3), res3)

res4 = res2.decode('gbk')
print(type(res4), res4)

# 注意：编码的方式和解码的方式必须一致
res5 = res1.decode('gbk')
print(type(res5), res5)

res6 = res2.decode('utf8')
print(type(res6), res6)
