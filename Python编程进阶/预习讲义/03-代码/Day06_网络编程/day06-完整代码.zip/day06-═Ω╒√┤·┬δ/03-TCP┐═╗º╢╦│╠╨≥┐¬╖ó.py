"""
TCP客户端程序开发
学习目标：理解 TCP 客户端程序的开发流程
"""

"""
TCP客户端程序开发步骤：
1）创建客户端套接字对象
2）和服务端套接字建立连接
3）发送数据
4）接收数据
5）关闭客户端套接字
"""
import socket

# 创建一个客户端的套接子 socket 对象
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 通过客户端socket连接服务器
client.connect(('127.0.0.1', 8080))

# 给服务器发送一个消息
send_msg = input('请输入发送的消息：') # str
client.send(send_msg.encode())

# 接收服务器响应的消息
recv_msg = client.recv(1024) # bytes
print('服务器响应的消息为：', recv_msg.decode())

# 关闭客户端的套接字对象
client.close()