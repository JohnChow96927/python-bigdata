"""
FastAPI基本使用-HelloWorld程序
学习目标：能够使用 FastAPI 完成 HelloWorld 案例程序
"""
