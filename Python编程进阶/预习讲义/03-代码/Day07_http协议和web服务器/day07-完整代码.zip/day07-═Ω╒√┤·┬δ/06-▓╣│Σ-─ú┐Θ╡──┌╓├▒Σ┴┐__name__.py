
# from smart import add, Dog
#
# res = add(1, 2)
# print(res)
#
# dog1 = Dog('小黑', 1)
# print(dog1.name)
# print(dog1.age)

import smart

# print(smart.__name__)

import random
