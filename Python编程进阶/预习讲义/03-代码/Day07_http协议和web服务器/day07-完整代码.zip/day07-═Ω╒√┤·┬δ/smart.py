num = 0

# 模块中有一个内置变量：__name__
# __name__内置变量的值有两种情况
# ① 如果在当前模块中获取当前模块的__name__，值就是 "__main__"
# ② 如果在其他模块中获取这个模块的__name__，值就是整个模块名称


def add(a, b):
    return a + b


def sub(a, b):
    return a - b


class Dog(object):
    def __init__(self, _name, _age):
        self.name = _name
        self.age = _age


# print(__name__)

# 给模块添加一些测试代码
if __name__ == '__main__':
    res = add(1, 3)
    print(res)