"""
简单Web服务器-返回任意html内容
学习目标：能够实现Web服务器给浏览器返回任意html内容
"""

import socket
import os

# 创建一个服务端监听套接字socket对象
# socket.AF_INET：表示使用 IPV4 地址
# socket.SOCK_STREAM：表示使用 TCP 协议
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 门迎
# 设置端口重用，服务器程序关闭之后，端口马上能够重复使用
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)

# 绑定服务端程序监听的 IP 和 PORT
server.bind(('127.0.0.1', 8080))

# 设置服务器监听，127表示同一时间最多处理127个客户端连接请求
server.listen(127)
print('服务器开始进行监听...')

while True:
    # 等待接受客户端的连接：如果没有客户端连接时，这句代码会阻塞等待，直到有客户端连接
    # server_client：和客户端进行通信的 socket 对象，服务员
    # ip_port：客户端的 IP 和 Port
    server_client, ip_port = server.accept()
    print(f'接受到来自客户端{ip_port}的连接请求...')

    # 接受客户端发送的消息，1024表示最多接受1024个字节
    # 如果客户端没有发消息，recv方法会阻塞等待
    recv_msg = server_client.recv(1024) # 返回值是 bytes 类型
    print('客户端发送的消息为：\n', recv_msg.decode())

    # 解析请求报文内容，获取浏览器请求的 URL 地址
    recv_msg = recv_msg.decode() # bytes -> str
    # 将请求报文按照 \r\n 进行分割
    request_list = recv_msg.split('\r\n')
    print(request_list)
    # 获取请求行的数据
    request_line = request_list[0]
    # 将请求行的数据按照空格进行分割
    request_line_list = request_line.split(' ')
    print(request_line_list)
    # 获取请求行中的 URL 地址
    request_url = request_line_list[1]

    if request_url == '/':
        file_path = './sources/html/gdp.html'
    else:
        file_path = './sources/html' + request_url

    # 组织 HTTP 响应报文并返回，根据浏览器请求的 URL 地址并返回相应的 html 内容
    # 响应行
    response_line = 'HTTP/1.1 200 OK\r\n'
    # 响应头
    response_header = 'Server: Python\r\n'

    # 响应体
    # 根据请求行中的 URL 地址获取对应的 html 内容，作为响应体
    # 判断要读取的文件是否存在
    if os.path.isfile(file_path):
        # 文件存在
        # f = open(file_path, 'r', encoding='utf8')
        # response_body = f.read()
        # f.close()

        with open(file_path, 'r', encoding='utf8') as f:
            response_body = f.read()
    else:
        # 文件不存在
        response_body = 'Not Found!!!'

    # 组织响应报文，进行返回
    send_msg = response_line + response_header + '\r\n' + response_body
    server_client.send(send_msg.encode())

    # 关闭和客户端通信的套接字、监听套接字
    server_client.close()

server.close()


