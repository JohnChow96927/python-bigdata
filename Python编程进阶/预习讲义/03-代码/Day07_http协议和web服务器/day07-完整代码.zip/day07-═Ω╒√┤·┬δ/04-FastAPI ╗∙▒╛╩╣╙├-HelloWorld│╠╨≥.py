"""
FastAPI基本使用-HelloWorld程序
学习目标：能够使用 FastAPI 完成 HelloWorld 案例程序
"""
# 1. 导入模块
# 导入 FastAPI 类
from fastapi import FastAPI
# 导入 uvicorn 模块：web服务器
import uvicorn

# 2. 创建一个 FastAPI 类的实例对象
app = FastAPI()


# 需求：通过浏览器访问 /index 这个 URL 地址时，给浏览器返回 Hello World
# app：就是上面的 FastAPI 类的示例对象
# get：app对象的一个方法，这个get表示支持get方式请求
# /index：表示 url 地址
@app.get('/index')
def index():
    # return 后面的内容就是响应报文中响应体的内容
    return 'Hello World'


if __name__ == '__main__':
    # 启动 web 服务器程序
    uvicorn.run(app, host='127.0.0.1', port=8080)

